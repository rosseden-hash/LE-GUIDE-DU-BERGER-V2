Icône source 1024×1024 pour générer les ressources Android via @capacitor/assets.
