@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==================================================
echo LE GUIDE DU BERGER V27 - Compilation APK Android
echo ==================================================
where node >nul 2>nul || (echo ERREUR : Node.js 20+ est requis. & goto error)
where npm >nul 2>nul || (echo ERREUR : npm est absent. & goto error)
where java >nul 2>nul || (echo ERREUR : un JDK est requis. & goto error)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (echo ERREUR : Android SDK non detecte. Configure Android Studio, ANDROID_HOME ou ANDROID_SDK_ROOT. & goto error)
node -e "const a=+process.versions.node.split('.')[0];if(a<20)process.exit(1)" || (echo ERREUR : Node.js 20+ est requis. & goto error)
call npm install
if errorlevel 1 goto error
if not exist android\gradlew.bat (
  echo Creation du projet Android natif...
  call npx cap add android
  if errorlevel 1 goto error
)
echo Generation des icones Android...
call npx capacitor-assets generate --android
if errorlevel 1 goto error
echo Synchronisation des fichiers de l'application...
call npx cap sync android
if errorlevel 1 goto error
echo Compilation de l'APK debug...
call android\gradlew.bat -p android assembleDebug
if errorlevel 1 goto error
if not exist dist mkdir dist
copy /Y android\app\build\outputs\apk\debug\app-debug.apk dist\LE-GUIDE-DU-BERGER-V27-debug.apk >nul
if errorlevel 1 goto error
echo.
echo SUCCES : APK generee :
echo %CD%\dist\LE-GUIDE-DU-BERGER-V27-debug.apk
echo APK debug pour essais uniquement ; test sur telephone requis.
pause
exit /b 0
:error
echo.
echo ECHEC. Verifie Node.js 20+, JDK, Android Studio/SDK, variables ANDROID_HOME et la connexion Internet.
echo Consulte README-ANDROID.md pour les prerequis.
pause
exit /b 1
