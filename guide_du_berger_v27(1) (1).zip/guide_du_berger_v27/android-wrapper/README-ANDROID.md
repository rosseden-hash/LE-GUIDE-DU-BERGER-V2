# LE GUIDE DU BERGER V27 — préparation de l’APK Android

## Statut exact
Ce dossier contient les sources web, la configuration Capacitor, l’image source de l’icône et des scripts de compilation. **Il ne contient pas d’APK compilée.** Cette session n’a pas Android SDK/Gradle configuré, donc la compilation doit être lancée sur un ordinateur compatible.

## Prérequis
- Windows, macOS ou Linux ; un téléphone seul ne suffit pas pour ce script.
- Node.js 20+ et npm.
- JDK compatible avec Android Gradle Plugin.
- Android Studio avec Android SDK Platform, Build-Tools et Command-line Tools installés.
- `ANDROID_HOME` ou `ANDROID_SDK_ROOT` configuré vers le SDK.
- Connexion Internet pour installer les dépendances npm et Gradle.

## Compiler une APK debug
1. Extraire l’archive V27 complète.
2. Ouvrir le dossier `android-wrapper`.
3. Windows : lancer `PREPARER-APK-WINDOWS.bat`.
4. macOS/Linux : lancer `./PREPARER-APK-MAC-LINUX.sh` depuis un terminal.
5. Si la compilation réussit, l’APK sera copiée dans `android-wrapper/dist/LE-GUIDE-DU-BERGER-V27-debug.apk`.

Le script vérifie la présence de Node.js, npm, Java et du SDK, installe les dépendances, crée le projet Android si nécessaire, génère les icônes à partir de `resources/icon.png`, synchronise Capacitor et lance `assembleDebug`. Il s’arrête avec un message si les prérequis de base manquent.

## Données et tests
- Les données du navigateur Chrome ne sont pas automatiquement copiées dans la WebView de l’APK. Exporte une sauvegarde JSON depuis l’ancienne version et teste son import dans l’APK avant d’effacer quoi que ce soit.
- L’APK debug doit être installée et testée sur un appareil réel : création/modification de personnes, prières, jeûnes, rappels, présences, import/export, fermeture/réouverture et stockage.
- Les notifications lorsque l’application est fermée ne sont pas garanties par cette version web ; une intégration native et des tests spécifiques seraient nécessaires.
- Pour distribuer publiquement l’application, il faudra créer une version release et la signer.
