#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
printf '\nLE GUIDE DU BERGER V27 — vérification et compilation Android\n'
command -v node >/dev/null 2>&1 || { echo 'ERREUR : Node.js est requis.'; exit 1; }
command -v npm >/dev/null 2>&1 || { echo 'ERREUR : npm est requis.'; exit 1; }
command -v java >/dev/null 2>&1 || { echo 'ERREUR : un JDK est requis.'; exit 1; }
node -e 'const [a,b]=process.versions.node.split(".").map(Number); if(a<20){console.error("Node.js 20+ requis");process.exit(1)}'
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo 'ERREUR : Android SDK non détecté. Installe-le via Android Studio et définis ANDROID_HOME ou ANDROID_SDK_ROOT.'
  exit 1
fi
npm install
if [ ! -f android/gradlew ]; then npx cap add android; fi
# Génère les icônes Android à partir de resources/icon.png si l'outil est disponible.
npx capacitor-assets generate --android
npx cap sync android
chmod +x android/gradlew
(cd android && ./gradlew assembleDebug)
mkdir -p dist
cp android/app/build/outputs/apk/debug/app-debug.apk dist/LE-GUIDE-DU-BERGER-V27-debug.apk
printf '\nAPK créée : %s/dist/LE-GUIDE-DU-BERGER-V27-debug.apk\n' "$PWD"
echo 'APK debug pour essais uniquement ; test sur téléphone requis.'
